// ============================================================
//  轰轰地吃 - 重庆美食地图
//  输入店名 → 高德自动搜索 → 选结果自动填地址和坐标
//  移除美食类型选择（后台审核时划分）
//  支持餐厅图片上传
//  生动有趣 · 微交互增强版
// ============================================================

const API_BASE = '';
// 带重试的 fetch：失败后自动重试 n 次
async function fetchWithRetry(url, options = {}, retries = 2) {
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      if (json && json.success === false) throw new Error(json.error || '请求失败');
      return json;
    } catch (err) {
      if (i < retries) {
        console.warn(`[retry] ${url} 失败，第 ${i+1} 次重试:`, err.message);
        await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        continue;
      }
      throw err;
    }
  }
}
// 渲染加载失败空态（带重试按钮）
function renderErrorRetry(containerId, message, retryFn) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const uid = 'retry-' + Date.now();
  el.innerHTML = `<div class="empty-state"><span class="empty-state-icon">😵</span><div class="empty-state-title">${message}</div><div class="empty-state-desc">网络好像出了点问题<br>检查一下服务器是否在运行？</div><button class="btn btn-primary" id="${uid}">🔄 重试</button></div>`;
  document.getElementById(uid)?.addEventListener('click', retryFn);
}
const MAP_CENTER = [106.55, 29.56];
const MAP_ZOOM_LEVEL = 12;

let map = null;
let markers = [];
let restaurants = [];
let categories = [];
let currentInfoWindow = null;
let activeCategory = '';
let topSearchValue = '';
let activeRatingFilter = 0; // 0=全部, 1-5=按评分等级过滤
let autoComplete = null;
let placeSearch = null;

// ==================== 设备身份标识 ====================
let deviceId = null;

function getDeviceId() {
  if (deviceId) return deviceId;
  try {
    let stored = localStorage.getItem('hh_device_id');
    if (stored) {
      deviceId = stored;
      return deviceId;
    }
    // 生成新 UUID
    let newId;
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      newId = crypto.randomUUID();
    } else {
      newId = 'dev-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 11);
    }
    localStorage.setItem('hh_device_id', newId);
    deviceId = newId;
    return deviceId;
  } catch(e) {
    // localStorage 不可用时用内存
    if (!deviceId) deviceId = 'temp-' + Date.now().toString(36);
    return deviceId;
  }
}

// 页面加载时立即获取设备ID

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
  console.log('[init] DOMContentLoaded fired');
  startLoading();
});

// 双重保险：如果 DOMContentLoaded 没触发，用 window.onload 再试
window.addEventListener('load', () => {
  console.log('[init] window.onload fired');
  if (typeof startDanmaku === 'function' && !window.__danmakuStarted) {
    console.log('[init] Starting danmaku from load event as fallback');
    startDanmaku();
    window.__danmakuStarted = true;
  }
});

// 三重保险：1秒后强制检查
setTimeout(() => {
  const container = document.getElementById('danmaku-container');
  if (container && container.children.length === 0) {
    console.warn('[init] Danmaku container exists but no items found after 1s, force starting...');
    if (typeof startDanmaku === 'function' && !window.__danmakuStarted) {
      startDanmaku();
      window.__danmakuStarted = true;
    }
  }
}, 1000);

// ==================== 弹幕系统 ====================
const DANMAKU_TEXTS = [
  '没有什么是一顿火锅解决不了的',
  '如果有，那就两顿',
  '重庆人的一天：早餐小面，午餐火锅',
  '辣椒不是调料，是重庆人的灵魂',
  '在重庆，万物皆可涮',
  '微辣是重庆人对游客最后的温柔',
  '一碗小面，半座山城',
  '毛肚七上八下，这是仪式感',
  '火锅不是食物，是社交方式',
  '人生苦短，先吃碗小面',
  '在重庆，不吃辣才是矫情',
  '重庆美食哲学：无辣不欢，无麻不香',
  '吃的是味道，交的是朋友',
  '山城路难走，但为了吃，值了',
  '重庆人的胃，是用辣椒砌的',
  '美食是相逢最美好的理由',
  '儿豁，这家的毛肚真的夯',
  '不吃火锅，白来重庆',
  '小面的灵魂不在面，在佐料',
  '重庆烧烤：把辣味烤进灵魂里',
  '儿豁！又发现一家宝藏店',
  '重庆美食地图，带你吃遍山城',
  '辣是一种生活态度',
  '跟着轰轰地吃，绝对不踩雷',
  '这家店，本地人都在排队',
  '重庆美食的精髓：麻辣鲜香',
  '吃火锅不加醋，这是规矩',
  '重庆小面，一碗入魂',
  '轰轰地吃，吃得轰轰烈烈',
  '辣得流汗，才是真重庆'
];

let danmakuInterval = null;
let reviewDanmakuInterval = null;
let danmakuEnabled = true;
let danmakuReviewPool = [];

// 加载界面弹幕（硬编码趣味文案）
function startDanmaku() {
  if (window.__danmakuStarted) return;
  window.__danmakuStarted = true;

  const container = document.getElementById('danmaku-container');
  if (!container) return;

  function launchOne() {
    const el = document.createElement('div');
    el.className = 'danmaku-item danmaku-fun';
    el.textContent = DANMAKU_TEXTS[Math.floor(Math.random() * DANMAKU_TEXTS.length)];
    const top = 5 + Math.random() * 60;
    el.style.top = top + 'vh';
    el.style.animationDuration = (12 + Math.random() * 6) + 's';
    container.appendChild(el);
    el.addEventListener('animationend', () => {
      if (el.parentNode) el.parentNode.removeChild(el);
    });
  }

  for (let i = 0; i < 3; i++) {
    setTimeout(launchOne, i * 700);
  }
  danmakuInterval = setInterval(launchOne, 2400);
}

function stopDanmaku() {
  if (danmakuInterval) {
    clearInterval(danmakuInterval);
    danmakuInterval = null;
  }
  const container = document.getElementById('danmaku-container');
  if (container) container.innerHTML = '';
}

// ==================== 真实评价弹幕系统 ====================
let danmakuSpeed = 3000; // 弹幕速度（毫秒），可从后端设置覆盖

function toggleDanmaku() {
  danmakuEnabled = !danmakuEnabled;
  const btn = document.getElementById('danmaku-toggle');
  if (btn) {
    btn.classList.toggle('active', danmakuEnabled);
  }
  if (danmakuEnabled) {
    startReviewDanmaku();
  } else {
    stopReviewDanmaku();
  }
}

function startReviewDanmaku() {
  if (!danmakuEnabled) return;
  const container = document.getElementById('danmaku-container');
  if (!container) return;

  fetch(`${API_BASE}/api/reviews/danmaku`)
    .then(r => r.json())
    .then(res => {
      // 读取后端弹幕设置
      if (res.settings) {
        if (res.settings.enabled === false) {
          console.log('[danmaku] 后端已关闭弹幕');
          stopReviewDanmaku();
          return;
        }
        if (res.settings.speed) danmakuSpeed = res.settings.speed;
      }

      if (res.success && res.data && res.data.length > 0) {
        danmakuReviewPool = res.data;
        console.log('[danmaku] Loaded', danmakuReviewPool.length, 'items for danmaku');
        launchReviewDanmakuItems();
        // 每30秒刷新一次数据
        if (reviewDanmakuInterval) clearInterval(reviewDanmakuInterval);
        reviewDanmakuInterval = setInterval(() => {
          if (!danmakuEnabled) return;
          fetch(`${API_BASE}/api/reviews/danmaku`)
            .then(r => r.json())
            .then(res => {
              if (res.success && res.data) {
                danmakuReviewPool = res.data;
              }
            }).catch(() => {});
        }, 30000);
      } else {
        // 没有数据，使用趣味文案弹幕
        console.log('[danmaku] No data, using fun texts');
        startDanmakuWithFunTexts();
      }
    }).catch(() => {
      startDanmakuWithFunTexts();
    });
}

function startDanmakuWithFunTexts() {
  if (!danmakuEnabled) return;
  const container = document.getElementById('danmaku-container');
  if (!container) return;

  function launchOne() {
    if (!danmakuEnabled) return;
    const el = document.createElement('div');
    el.className = 'danmaku-item danmaku-fun';
    el.textContent = DANMAKU_TEXTS[Math.floor(Math.random() * DANMAKU_TEXTS.length)];
    const top = 5 + Math.random() * 60;
    el.style.top = top + 'vh';
    el.style.animationDuration = (12 + Math.random() * 6) + 's';
    container.appendChild(el);
    el.addEventListener('animationend', () => {
      if (el.parentNode) el.parentNode.removeChild(el);
    });
  }

  for (let i = 0; i < 2; i++) {
    setTimeout(launchOne, i * 1000);
  }
  if (reviewDanmakuInterval) clearInterval(reviewDanmakuInterval);
  reviewDanmakuInterval = setInterval(launchOne, danmakuSpeed);
}

function launchReviewDanmakuItems() {
  if (!danmakuEnabled) return;
  const container = document.getElementById('danmaku-container');
  if (!container || danmakuReviewPool.length === 0) return;

  function launchOne() {
    if (!danmakuEnabled) return;
    const item = danmakuReviewPool[Math.floor(Math.random() * danmakuReviewPool.length)];
    if (!item) return;

    const el = document.createElement('div');

    // 区分评价弹幕和自定义弹幕
    if (item.source === 'custom') {
      // 自定义弹幕
      const typeClass = { fun: 'danmaku-fun', promo: 'danmaku-item', notice: 'danmaku-item' };
      el.className = typeClass[item.type] || 'danmaku-item danmaku-fun';
      if (item.type === 'notice') el.style.color = '#e67e22';
      if (item.type === 'promo') el.style.color = '#3498db';
      el.textContent = item.text;
    } else {
      // 评价弹幕
      el.className = getDanmakuClass(item);
      el.textContent = formatDanmakuText(item);
      el.dataset.restaurantId = item.restaurantId;
      el.dataset.lat = item.restaurantLatitude;
      el.dataset.lng = item.restaurantLongitude;
      el.style.cursor = 'pointer';

      // 点击弹幕定位到餐厅
      el.addEventListener('click', () => {
        const lat = parseFloat(el.dataset.lat);
        const lng = parseFloat(el.dataset.lng);
        if (lat && lng && map) {
          map.flyTo([lng, lat], 15, { duration: 1.5 });
          setTimeout(() => {
            const r = (window.restaurants || []).find(res => res.id === item.restaurantId);
            if (r && window.showRestaurantInfo) {
              window.showRestaurantInfo(r);
            }
          }, 1600);
        }
      });
    }

    const top = 5 + Math.random() * 60;
    el.style.top = top + 'vh';
    el.style.animationDuration = (10 + Math.random() * 8) + 's';

    // 悬停暂停
    el.addEventListener('mouseenter', () => { el.style.animationPlayState = 'paused'; });
    el.addEventListener('mouseleave', () => { el.style.animationPlayState = 'running'; });

    container.appendChild(el);
    el.addEventListener('animationend', () => {
      if (el.parentNode) el.parentNode.removeChild(el);
    });
  }

  // 初始发射2条
  for (let i = 0; i < 2; i++) {
    setTimeout(launchOne, i * 1000);
  }
  // 持续发射，使用后端设置的速度
  if (window._reviewDanmakuTimer) clearInterval(window._reviewDanmakuTimer);
  const jitter = Math.floor(danmakuSpeed * 0.5);
  window._reviewDanmakuTimer = setInterval(launchOne, danmakuSpeed + Math.random() * jitter);
}

function formatDanmakuText(rv) {
  const stars = '⭐'.repeat(rv.rating);
  const name = rv.reviewerName || '匿名';
  const text = rv.recommendReason || rv.comment || '';
  let prefix = '';
  if (rv.rating >= 5) {
    prefix = ['🔥', '💥', '✨'][Math.floor(Math.random() * 3)] + ' ';
  } else if (rv.rating <= 2) {
    prefix = '😅 ';
  }
  // 重庆方言随机前缀
  const dialects = ['儿豁 ', '豁你撒 ', '不摆了 '];
  if (Math.random() < 0.3) {
    prefix = dialects[Math.floor(Math.random() * dialects.length)] + prefix;
  }
  if (text) {
    return prefix + name + '：' + text + ' ' + stars;
  } else {
    return prefix + name + ' 推荐 ' + (rv.restaurantName || '') + ' ' + stars;
  }
}

function getDanmakuClass(rv) {
  if (rv.rating >= 5) return 'danmaku-item danmaku-hot';
  // 检查是否爆款（同一餐厅评价数≥5）
  const restaurantReviews = danmakuReviewPool.filter(r => r.restaurantId === rv.restaurantId);
  if (restaurantReviews.length >= 5) return 'danmaku-item danmaku-popular';
  return 'danmaku-item';
}

function stopReviewDanmaku() {
  if (reviewDanmakuInterval) {
    clearInterval(reviewDanmakuInterval);
    reviewDanmakuInterval = null;
  }
  if (window._reviewDanmakuTimer) {
    clearInterval(window._reviewDanmakuTimer);
    window._reviewDanmakuTimer = null;
  }
  const container = document.getElementById('danmaku-container');
  if (container) container.innerHTML = '';
}

// ==================== 弹幕点击定位 ====================
window.showRestaurantInfo = function(r) {
  if (!map || !r) return;
  if (window.currentInfoWindow) window.currentInfoWindow.close();
  const avg = r.avgRating ? parseFloat(r.avgRating) : 0;
  const stars = '⭐'.repeat(Math.round(avg)) + '☆'.repeat(5 - Math.round(avg));
  const content = `
    <div style="min-width:220px;font-family:'ZCOOL KuaiLe','Ma Shan Zheng',cursive;">
      <h4 style="margin:0 0 6px 0;font-size:15px;">${escHtml(r.name)}</h4>
      <div style="font-size:13px;color:#c84a3f;margin-bottom:4px;">${stars} ${avg > 0 ? avg.toFixed(1) : '暂无评分'}</div>
      <div style="font-size:12px;color:#888;margin-bottom:6px;">📍 ${escHtml(r.address || '地址未知')}</div>
      ${r.phone ? `<div style="font-size:12px;color:#666;margin-bottom:4px;">📞 ${escHtml(r.phone)}</div>` : ''}
      ${r.openingHours ? `<div style="font-size:12px;color:#666;margin-bottom:6px;">🕐 ${escHtml(r.openingHours)}</div>` : ''}
      <button onclick="showReviewForm(${r.id})" style="background:#c84a3f;color:#fff;border:none;padding:4px 12px;border-radius:6px;cursor:pointer;font-size:12px;">✍️ 写评价</button>
    </div>`;
  window.currentInfoWindow = new AMap.InfoWindow({
    content: content,
    offset: new AMap.Pixel(0, -30),
    closeWhenClickMap: true
  });
  window.currentInfoWindow.open(map, [r.longitude, r.latitude]);
};

// ==================== 加载动画（含摩托车）====================
function startLoading() {
  startDanmaku(); // 启动弹幕
  const percentEl = document.getElementById('loading-percent');
  const statusEl = document.getElementById('loading-status');
  const motorcycleEl = document.getElementById('loading-motorcycle');
  const progressFillEl = document.getElementById('loading-progress-fill');
  const noodleIcon = document.getElementById('loading-noodle-icon');
  const statuses = ['正在烫毛肚...','正在爆炒黄喉...','正在打油碟...','正在煮豌杂面...'];
  let progress = 0;
  let statusIdx = 0;
  let loadingDone = false;

  const statusInterval = setInterval(() => {
    statusIdx = (statusIdx + 1) % statuses.length;
    if (statusEl) statusEl.textContent = statuses[statusIdx];
  }, 800);

  function finishLoading() {
    if (loadingDone) return;
    loadingDone = true;
    clearInterval(interval);
    clearInterval(statusInterval);
    stopDanmaku(); // 停止加载弹幕
    percentEl.textContent = '100.0%';
    statusEl.textContent = '即将上桌...';
    if (motorcycleEl) motorcycleEl.style.left = 'calc(100% - 32px)';
    if (progressFillEl) progressFillEl.style.width = '100%';
    if (noodleIcon) noodleIcon.style.opacity = '0';
    setTimeout(() => {
      document.getElementById('loading-screen').classList.add('hidden');
      initApp();
      // 延迟启动真实评价弹幕（等地图初始化完成）
      setTimeout(() => {
        if (danmakuEnabled) startReviewDanmaku();
      }, 1500);
    }, 400);
  }

  const interval = setInterval(() => {
    if (loadingDone) return;
    // 减慢加载速度，让用户能看到弹幕（每400ms增加3-8%）
    progress += Math.random() * 5 + 3;
    if (progress >= 60 && !dataReady) {
      progress = 60;
    }
    if (progress >= 100) {
      progress = 100;
      finishLoading();
      return;
    }
    percentEl.textContent = progress.toFixed(1) + '%';
    if (motorcycleEl) motorcycleEl.style.left = 'calc(' + progress + '% - 16px)';
    if (progressFillEl) progressFillEl.style.width = progress + '%';
  }, 400);

  Promise.all([
    fetch(`${API_BASE}/api/categories`).then(r => r.json()),
    fetch(`${API_BASE}/api/restaurants`).then(r => r.json())
  ]).then(() => {
    dataReady = true;
    if (!loadingDone) {
      progress = 85;
      percentEl.textContent = '85.0%';
      if (progressFillEl) progressFillEl.style.width = '85%';
      setTimeout(() => finishLoading(), 300);
    }
  }).catch(() => {
    dataReady = true;
    if (!loadingDone) setTimeout(() => finishLoading(), 500);
  });
}

let dataReady = false;
let mapReady = false;

function initApp() {
  // 微信浏览器 100vh 修复
  const setVH = () => {
    const vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
  };
  setVH();
  window.addEventListener('resize', setVH);

  initMap();
  bindEvents();
  loadCategories(() => {
    loadRestaurants();
  });
  loadAnnouncements();
  // ★ 效果8：初始化搜索框趣味占位轮换
  initRotatingPlaceholder();
  // 弹幕按钮初始状态（默认开启）
  const danmakuBtn = document.getElementById('danmaku-toggle');
  if (danmakuBtn) danmakuBtn.classList.toggle('active', danmakuEnabled);
}

// ==================== 地图初始化 ====================
function initMap() {
  map = new AMap.Map('map', {
    center: MAP_CENTER,
    zoom: MAP_ZOOM_LEVEL,
    zooms: [10, 18],
    resizeEnable: true,
    mapStyle: 'amap://styles/normal',
    showIndoorMap: false
  });

  AMap.plugin(['AMap.AutoComplete', 'AMap.PlaceSearch'], function () {
    autoComplete = new AMap.AutoComplete({ city: '重庆' });
    placeSearch = new AMap.PlaceSearch({ city: '重庆', pageSize: 8 });
    console.log('高德搜索插件加载成功');
    bindPlaceSearch('rec-name', 'rec-autocomplete', 'rec-address', 'rec-lat', 'rec-lng');
    mapReady = true;
    // 如果数据已就绪但loading还在等，现在可以结束
    if (dataReady) {
      const percentEl = document.getElementById('loading-percent');
      const progressFillEl = document.getElementById('loading-progress-fill');
      if (percentEl && parseFloat(percentEl.textContent) < 85) {
        percentEl.textContent = '85.0%';
        if (progressFillEl) progressFillEl.style.width = '85%';
      }
    }
  });

  const sw = new AMap.LngLat(105.47, 28.10);
  const ne = new AMap.LngLat(110.11, 32.13);
  map.setLimitBounds(new AMap.Bounds(sw, ne));
}

// ==================== 高德搜索自动匹配 ====================
function bindPlaceSearch(inputId, dropdownId, addressId, latId, lngId) {
  const input = document.getElementById(inputId);
  const dropdown = document.getElementById(dropdownId);
  if (!input || !dropdown) return;

  let debounceTimer = null;

  input.addEventListener('input', () => {
    const keyword = input.value.trim();
    if (!keyword) {
      dropdown.style.display = 'none';
      return;
    }
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      doPlaceSearch(keyword, dropdown, input, addressId, latId, lngId);
    }, 300);
  });

  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target) && e.target !== input) {
      dropdown.style.display = 'none';
    }
  });
}

function doPlaceSearch(keyword, dropdown, input, addressId, latId, lngId) {
  dropdown.innerHTML = '<div class="autocomplete-item" style="cursor:default;"><div class="ac-name">🔍 正在搜索 "' + escHtml(keyword) + '"...</div></div>';
  dropdown.style.display = 'block';

  fetch(`${API_BASE}/api/search?keyword=${encodeURIComponent(keyword)}`)
    .then(res => res.json())
    .then(json => {
      console.log('【后端搜索】结果:', json);
      if (json.success && json.data && json.data.length > 0) {
        showAutoCompleteResults(json.data, dropdown, input, addressId, latId, lngId);
      } else {
        dropdown.innerHTML = '<div class="autocomplete-item" style="cursor:default;"><div class="ac-name">😔 未找到相关餐厅</div><div class="ac-address">尝试输入更精确的名称</div></div>';
      }
    })
    .catch(err => {
      console.error('【后端搜索】出错:', err);
      dropdown.style.display = 'none';
    });
}

function showAutoCompleteResults(tips, dropdown, input, addressId, latId, lngId) {
  const validTips = tips.filter(t => t.name && t.name.trim() !== '');
  if (validTips.length === 0) {
    dropdown.style.display = 'none';
    return;
  }

  dropdown._tips = validTips;

  dropdown.innerHTML = validTips.map((tip, idx) => {
    const addr = tip.district ? tip.district + (tip.address ? ' · ' + tip.address : '') : (tip.address || '');
    return `<div class="autocomplete-item" data-idx="${idx}"
                 data-name="${escHtml(tip.name)}"
                 data-address="${escHtml(addr)}">
      <div class="ac-name">${escHtml(tip.name)}</div>
      <div class="ac-address">${escHtml(addr)}</div>
    </div>`;
  }).join('');

  dropdown.style.display = 'block';

  dropdown.querySelectorAll('.autocomplete-item').forEach(item => {
    item.addEventListener('click', () => {
      const idx     = parseInt(item.dataset.idx);
      const name    = item.dataset.name;
      const address = item.dataset.address;

      input.value = name;

      const addrEl = document.getElementById(addressId);
      if (addrEl) addrEl.value = address;

      const tip = dropdown._tips ? dropdown._tips[idx] : null;
      if (tip && tip.location) {
        const locStr = tip.location;
        console.log('【坐标解析】location 原始值:', locStr);
        let lng, lat;
        if (typeof locStr === 'string' && locStr.includes(',')) {
          const parts = locStr.split(',');
          lng = parseFloat(parts[0]);
          lat = parseFloat(parts[1]);
        } else if (typeof locStr === 'object') {
          lng = parseFloat(locStr.lng != null ? locStr.lng : locStr.L);
          lat = parseFloat(locStr.lat != null ? locStr.lat : locStr.N);
        }
        if (lng && lat && !isNaN(lng) && !isNaN(lat)) {
          console.log('【坐标解析】成功:', lng, lat);
          fillCoords(latId, lngId, lat, lng);
        } else {
          console.warn('【坐标解析】失败:', locStr);
        }
      } else {
        console.warn('【坐标解析】tip 或 location 不存在');
      }

      dropdown.style.display = 'none';
    });
  });
}

function fillCoords(latId, lngId, lat, lng) {
  const latEl = document.getElementById(latId);
  const lngEl = document.getElementById(lngId);
  if (latEl) { latEl.value = parseFloat(lat).toFixed(6); }
  if (lngEl) { lngEl.value = parseFloat(lng).toFixed(6); }
  if (map && lng && lat) {
    map.setCenter([parseFloat(lng), parseFloat(lat)]);
    map.setZoom(16);
  }
}

// ==================== 图片上传 ====================
function bindImageUpload(uploadAreaId, fileInputId, previewId, pathInputId) {
  const area     = document.getElementById(uploadAreaId);
  const fileIn   = document.getElementById(fileInputId);
  const preview  = document.getElementById(previewId);
  const pathIn   = document.getElementById(pathInputId);
  if (!area || !fileIn) return;

  area.addEventListener('click', () => fileIn.click());

  fileIn.addEventListener('change', () => {
    const file = fileIn.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      if (preview) {
        preview.src = e.target.result;
        preview.style.display = 'block';
      }
      const placeholder = area.querySelector('.upload-placeholder');
      if (placeholder) placeholder.style.display = 'none';

      uploadImage(file, pathInputId);
    };
    reader.readAsDataURL(file);
  });
}

function uploadImage(file, pathInputId) {
  const formData = new FormData();
  formData.append('image', file);

  fetch(`${API_BASE}/api/upload`, {
    method: 'POST',
    body: formData
  })
    .then(res => res.json())
    .then(json => {
      if (json.success) {
        const pathIn = document.getElementById(pathInputId);
        if (pathIn) pathIn.value = json.data.path;
      } else {
        console.error('图片上传失败：', json.error);
      }
    })
    .catch(err => console.error('图片上传出错：', err));
}

let recImagePaths = [];

window.uploadRecImage = function() {
  const fileInput = document.getElementById('rec-image-input');
  if (!fileInput || !fileInput.files[0]) return;
  if (recImagePaths.length >= 3) { showErrorToast('最多上传3张图片哦'); fileInput.value = ''; return; }

  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append('image', file);

  fetch(`${API_BASE}/api/upload`, { method: 'POST', body: formData })
    .then(res => res.json())
    .then(json => {
      if (json.success) {
        recImagePaths.push(json.data.path);
        renderRecImagePreview();
        fileInput.value = '';
      } else {
        showErrorToast('图片上传失败：' + json.error);
      }
    })
    .catch(err => {
      console.error('推荐图片上传出错：', err);
      showErrorToast('图片上传失败，请重试');
    });
};

function renderRecImagePreview() {
  const preview = document.getElementById('rec-image-preview');
  if (!preview) return;
  preview.innerHTML = recImagePaths.map((path, idx) => `
    <div style="position:relative;display:inline-block;">
      <img src="${escHtml(path)}" style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid rgba(200,190,175,0.15);">
      <span style="position:absolute;top:-6px;right:-6px;width:18px;height:18px;background:#c84a3f;color:#fff;border-radius:50%;font-size:11px;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:1;" onclick="removeRecImage(${idx})">✕</span>
    </div>
  `).join('');
  const placeholder = document.getElementById('rec-upload-placeholder');
  if (placeholder) placeholder.style.display = recImagePaths.length >= 3 ? 'none' : '';
}

window.removeRecImage = function(idx) {
  recImagePaths.splice(idx, 1);
  renderRecImagePreview();
};

// ==================== 提交推荐 ====================
async function handleRecommend(e) {
  e.preventDefault();

  const name     = document.getElementById('rec-name').value.trim();
  const address  = document.getElementById('rec-address').value.trim();
  const reason   = document.getElementById('rec-reason').value.trim();
  const dishes   = document.getElementById('rec-dishes').value.trim();
  const cost     = document.getElementById('rec-cost').value;
  const bestTime = document.getElementById('rec-best-time').value.trim();
  const rating   = document.getElementById('rec-rating').value;
  const reviewer = document.getElementById('rec-reviewer').value.trim();
  const isOpen   = document.getElementById('rec-is-open').checked;
  const lat      = document.getElementById('rec-lat')?.value;
  const lng      = document.getElementById('rec-lng')?.value;
  const imagePath = document.getElementById('rec-image-path')?.value;

  if (!name)     { showErrorToast('请输入餐厅名称！'); return; }
  if (!rating)    { showErrorToast('请点击星星选择评分！'); return; }
  if (!reason)    { showErrorToast('请填写推荐理由！'); return; }
  if (!lat || !lng) { showErrorToast('请在下拉列表中选择餐厅以自动获取地址！'); return; }

  try {
    let restaurantId;
    const res1 = await fetch(`${API_BASE}/api/restaurants`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        latitude: parseFloat(lat),
        longitude: parseFloat(lng),
        address,
        imagePath,
        deviceId: getDeviceId()
      })
    });
    const json1 = await res1.json();
    if (!json1.success) {
      if (res1.status === 409 && json1.data) {
        restaurantId = json1.data.id;
      } else {
        throw new Error(json1.error);
      }
    } else {
      restaurantId = json1.data.id;
    }

    const res2 = await fetch(`${API_BASE}/api/restaurants/${restaurantId}/reviews`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reviewerName: reviewer,
        rating: parseInt(rating),
        comment: '',
        recommendReason: reason,
        signatureDishes: dishes,
        avgCost: cost ? parseInt(cost) : 0,
        bestTime,
        isOpen,
        images: recImagePaths,
        deviceId: getDeviceId()
      })
    });
    const json2 = await res2.json();
    if (!json2.success) throw new Error(json2.error);

    showSuccessToast('感谢推荐！你的美食发现已提交，审核通过后会展示给大家 🎉');
    if (json2.newAchievements && json2.newAchievements.length > 0) {
      showAchievementUnlockToast(json2.newAchievements);
    }
    hideRecommendModal();
    await loadRestaurants();
    // ★ 效果10：辣椒油滴落波纹
    showChiliOilRipple(parseFloat(lat), parseFloat(lng));
    map.setCenter([parseFloat(lng), parseFloat(lat)]);
  } catch (err) {
    showErrorToast('提交失败：' + err.message);
  }
}

// ==================== 评价表单 ====================
window.showReviewForm = function(restaurantId) {
  const el = document.getElementById(`review-form-${restaurantId}`);
  if (el) el.style.display = 'block';
  initStarRatingInline(`rv-star-${restaurantId}`, `rv-star-label-${restaurantId}`, `rv-rating-${restaurantId}`);
  initReviewImageUpload(restaurantId);
  if (typeof currentInfoWindow !== 'undefined' && currentInfoWindow) {
    setTimeout(() => { try { currentInfoWindow.setSize(null); } catch(e) {} }, 10);
  }
};

window.hideReviewForm = function(restaurantId) {
  const el = document.getElementById(`review-form-${restaurantId}`);
  if (el) el.style.display = 'none';
  const preview = document.getElementById(`rv-preview-${restaurantId}`);
  if (preview) preview.innerHTML = '';
  const fileInput = document.getElementById(`rv-file-${restaurantId}`);
  if (fileInput) fileInput.value = '';
  if (el) el._imagePaths = [];
  if (typeof currentInfoWindow !== 'undefined' && currentInfoWindow) {
    setTimeout(() => { try { currentInfoWindow.setSize(null); } catch(e) {} }, 10);
  }
};

function initReviewImageUpload(restaurantId) {
  const el = document.getElementById(`review-form-${restaurantId}`);
  if (el) el._imagePaths = [];
}

window.uploadReviewImage = function(restaurantId) {
  const fileInput = document.getElementById(`rv-file-${restaurantId}`);
  if (!fileInput || !fileInput.files[0]) return;

  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append('image', file);

  fetch(`${API_BASE}/api/upload`, { method: 'POST', body: formData })
    .then(res => res.json())
    .then(json => {
      if (json.success) {
        const el = document.getElementById(`review-form-${restaurantId}`);
        if (!el._imagePaths) el._imagePaths = [];
        el._imagePaths.push(json.data.path);

        const preview = document.getElementById(`rv-preview-${restaurantId}`);
        if (preview) {
          const img = document.createElement('img');
          img.src = json.data.path;
          img.style.cssText = 'width:48px;height:48px;object-fit:cover;border-radius:6px;';
          preview.appendChild(img);
        }
        fileInput.value = '';
      } else {
        showErrorToast('图片上传失败：' + json.error);
      }
    })
    .catch(err => {
      console.error('评价图片上传出错：', err);
      showErrorToast('图片上传失败，请重试');
    });
};

window.submitReview = async function(restaurantId) {
  const name    = document.getElementById(`rv-name-${restaurantId}`).value.trim();
  const rating  = document.getElementById(`rv-rating-${restaurantId}`).value;
  const comment = document.getElementById(`rv-comment-${restaurantId}`).value.trim();
  const reason  = document.getElementById(`rv-reason-${restaurantId}`)?.value.trim() || '';
  const dishes  = document.getElementById(`rv-dishes-${restaurantId}`)?.value.trim() || '';
  const cost    = document.getElementById(`rv-cost-${restaurantId}`)?.value || '0';

  if (!rating) { showErrorToast('请点击星星选择评分！'); return; }

  const el = document.getElementById(`review-form-${restaurantId}`);
  const imagePaths = (el && el._imagePaths) ? el._imagePaths : [];

  try {
    const res = await fetch(`${API_BASE}/api/restaurants/${restaurantId}/reviews`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reviewerName: name,
        rating: parseInt(rating),
        comment,
        recommendReason: reason,
        signatureDishes: dishes,
        avgCost: parseInt(cost) || 0,
        images: imagePaths,
        deviceId: getDeviceId()
      })
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error);
    showSuccessToast(json.message || '评价已提交，等待管理员审核！');
    if (json.newAchievements && json.newAchievements.length > 0) {
      showAchievementUnlockToast(json.newAchievements);
    }
    hideReviewForm(restaurantId);
    loadRestaurants();
  } catch (err) {
    showErrorToast('提交失败：' + err.message);
  }
};

// ==================== 事件绑定 ====================
function bindEvents() {
  const btnRefresh = document.getElementById('btn-refresh');
  if (btnRefresh) btnRefresh.addEventListener('click', loadRestaurants);

  const topSearch = document.getElementById('top-search');
  if (topSearch) {
    topSearch.addEventListener('input', (e) => {
      topSearchValue = e.target.value.trim().toLowerCase();
      renderSidebarList();
    });
  }

  const fabRecommend = document.getElementById('fab-recommend');
  if (fabRecommend) fabRecommend.addEventListener('click', showRecommendModal);

  const btnCancelRec = document.getElementById('btn-cancel-rec');
  if (btnCancelRec) btnCancelRec.addEventListener('click', hideRecommendModal);

  const recommendForm = document.getElementById('recommend-form');
  if (recommendForm) recommendForm.addEventListener('submit', handleRecommend);

  initStarRating('rec-star-rating', 'rec-star-label', 'rec-rating');

  const btnRandom = document.getElementById('btn-random');
  if (btnRandom) btnRandom.addEventListener('click', showRandomRestaurant);

  const btnAchievements = document.getElementById('btn-achievements');
  if (btnAchievements) {
    btnAchievements.addEventListener('click', (e) => {
      e.preventDefault();
      showAchievementModal();
    });
  }
  const btnCloseAchievement = document.getElementById('btn-close-achievement');
  if (btnCloseAchievement) btnCloseAchievement.addEventListener('click', hideAchievementModal);

  const btnRanking = document.getElementById('btn-ranking');
  if (btnRanking) btnRanking.addEventListener('click', showRankingModal);
  const btnCloseRanking = document.getElementById('btn-close-ranking');
  if (btnCloseRanking) btnCloseRanking.addEventListener('click', hideRankingModal);
}

// ==================== 弹窗控制 ====================
function showRecommendModal() {
  document.getElementById('recommend-modal').style.display = 'flex';
  resetStarRating('rec-star-rating', 'rec-star-label', 'rec-rating');
}

function hideRecommendModal() {
  document.getElementById('recommend-modal').style.display = 'none';
  document.getElementById('recommend-form').reset();
  document.getElementById('rec-lat').value = '';
  document.getElementById('rec-lng').value = '';
  document.getElementById('rec-image-path').value = '';
  recImagePaths = [];
  const preview = document.getElementById('rec-image-preview');
  if (preview) preview.innerHTML = '';
  const placeholder = document.getElementById('rec-upload-placeholder');
  if (placeholder) placeholder.style.display = '';
  const fileInput = document.getElementById('rec-image-input');
  if (fileInput) fileInput.value = '';
  resetStarRating('rec-star-rating', 'rec-star-label', 'rec-rating');
  const optFields = document.getElementById('rec-optional-fields');
  if (optFields) optFields.style.display = 'none';
  const optArrow = document.getElementById('rec-optional-arrow');
  if (optArrow) optArrow.textContent = '▶';
}

window.toggleRecOptional = function() {
  const fields = document.getElementById('rec-optional-fields');
  const arrow = document.getElementById('rec-optional-arrow');
  if (!fields) return;
  const isOpen = fields.style.display !== 'none';
  fields.style.display = isOpen ? 'none' : 'block';
  if (arrow) arrow.textContent = isOpen ? '▶' : '▼';
};

// ==================== 加载公告 ====================
async function loadAnnouncements() {
  try {
    const res = await fetch(`${API_BASE}/api/announcements`);
    const json = await res.json();
    if (!json.success) return;
    const el = document.getElementById('announcement-content');
    if (!el) return;
    const list = json.data || [];
    if (list.length === 0) {
      el.innerHTML = '<div class="announcement-item">暂无公告</div>';
    } else {
      el.innerHTML = list.map(a =>
        `<div class="announcement-item">${escHtml(a.text)}</div>`
      ).join('');
    }
  } catch (err) {
    console.error('加载公告失败：', err);
  }
}

// ==================== 加载骨架屏 ====================
function showSkeleton(count = 5) {
  const el = document.getElementById('restaurant-list');
  if (!el) return;
  el.innerHTML = Array.from({length: count}, () =>
    `<div class="skeleton-card"><div class="skeleton-avatar"></div><div class="skeleton-lines"><div class="skeleton-line"></div><div class="skeleton-line"></div></div><div class="skeleton-tag"></div></div>`
  ).join('');
}

// ==================== 加载餐厅 ====================
function loadRestaurants() {
  showSkeleton(5);
  fetchWithRetry(`${API_BASE}/api/restaurants`)
    .then(json => {
      restaurants = json.data;
      updateCategoryCounts();
      renderMarkers();
      renderSidebarList();
    })
    .catch(err => {
      console.error('加载餐厅失败：', err);
      renderErrorRetry('restaurant-list', '加载失败', loadRestaurants);
    });
}

function updateCategoryCounts() {
  const counts = {};
  restaurants.forEach(r => {
    const cat = r.category || '未分类';
    counts[cat] = (counts[cat] || 0) + 1;
  });
  const allEl = document.getElementById('count-all');
  if (allEl) allEl.textContent = restaurants.length;
  if (categories) {
    categories.forEach(cat => {
      const el = document.getElementById(`count-${cat.name}`);
      if (el) el.textContent = counts[cat.name] || 0;
    });
  }
}

// ==================== 评分等级辅助函数 ====================
function getRatingLevel(avgRating) {
  const r = parseFloat(avgRating) || 0;
  if (r >= 4.5) return 5; // 🤩 夯
  if (r >= 3.5) return 4; // 😋 顶级
  if (r >= 2.5) return 3; // 🙂 人上人
  if (r >= 0.5) return 2; // 😐 NPC
  return 1;               // 😫 拉完了
}

// ==================== 渲染标记 ====================
function renderMarkers() {
  markers.forEach(m => m.setMap(null));
  markers = [];

  let filtered = restaurants;
  if (activeCategory) filtered = filtered.filter(r => r.category === activeCategory);
  if (activeRatingFilter > 0) filtered = filtered.filter(r => getRatingLevel(r.avgRating) === activeRatingFilter);
  if (topSearchValue) {
    filtered = filtered.filter(r =>
      r.name.toLowerCase().includes(topSearchValue) ||
      (r.address && r.address.toLowerCase().includes(topSearchValue)) ||
      (r.searchKeywords && r.searchKeywords.includes(topSearchValue))
    );
  }

  filtered.forEach((r, idx) => {
    const { color, emoji } = getCategoryStyle(r.category);
    const count = r.reviewCount || 0;
    const rating = parseFloat(r.avgRating) || 0;

    let sizeClass = 'marker-sm';
    let offsetPx = -18;
    if (count >= 11) { sizeClass = 'marker-lg'; offsetPx = -26; }
    else if (count >= 3) { sizeClass = 'marker-md'; offsetPx = -22; }

    let glowClass = '';
    let face = emoji;
    if (rating >= 4.5) { glowClass = 'marker-glow'; face = '🤩'; }
    else if (rating >= 3.5) { face = '😋'; }
    else if (rating >= 2.5) { face = '🙂'; }
    else if (rating > 0) { face = '😫'; }

    const wrapper = document.createElement('div');
    wrapper.className = 'custom-marker';
    wrapper.style.animationDelay = (idx * 0.08) + 's';

    const bubble = document.createElement('div');
    bubble.className = `marker-bubble ${sizeClass} ${glowClass}`;
    bubble.style.background = color;
    const badge = count > 0 ? `<span class="marker-count ${sizeClass}">${count}</span>` : '';
    bubble.innerHTML = `<span class="marker-face ${sizeClass}">${face}</span>${badge}`;

    const label = document.createElement('div');
    label.className = 'marker-label';
    label.innerHTML = `<span class="marker-name">${escHtml(r.name)}</span>${rating > 0 ? `<span class="marker-rating">${rating}</span>` : ''}`;

    wrapper.appendChild(bubble);
    wrapper.appendChild(label);

    const marker = new AMap.Marker({
      position: [r.longitude, r.latitude],
      content: wrapper,
      offset: new AMap.Pixel(offsetPx, offsetPx - 14),
      anchor: 'center'
    });

    marker.restaurantId = r.id;
    marker.on('click', () => openInfoWindow(r, marker));
    marker.setMap(map);
    markers.push(marker);
  });
}

function getCategoryStyle(category) {
  // 统一使用暖红色背景，emoji 保留分类辨识度
  const UNIFIED_COLOR = '#e0503f';
  const map = {
    '火锅':  { color: UNIFIED_COLOR, emoji: '🌶️' },
    '小面':  { color: UNIFIED_COLOR, emoji: '🍜' },
    '烧烤':  { color: UNIFIED_COLOR, emoji: '🍢' },
    '江湖菜':{ color: UNIFIED_COLOR, emoji: '🥘' },
    '串串':  { color: UNIFIED_COLOR, emoji: '🍡' },
    '咖啡店':{ color: UNIFIED_COLOR, emoji: '☕' },
    '景点':  { color: UNIFIED_COLOR, emoji: '📍' },
    '夜宵':  { color: UNIFIED_COLOR, emoji: '🌙' }
  };
  return map[category] || { color: UNIFIED_COLOR, emoji: '🍽️' };
}

function getReviewTagStyle(rating) {
  const styles = {
    5: 'background:rgba(230,126,34,0.15);color:#e67e22',
    4: 'background:rgba(230,126,34,0.1);color:#c87f2a',
    3: 'background:rgba(138,126,108,0.1);color:#8a7e6c',
    2: 'background:rgba(150,150,150,0.08);color:#999',
    1: 'background:rgba(200,74,63,0.08);color:#c84a3f'
  };
  return styles[rating] || styles[3];
}

const STAR_LABELS = { 1: '拉完了', 2: 'NPC', 3: '人上人', 4: '顶级', 5: '夯' };

// ==================== InfoWindow ====================
async function openInfoWindow(restaurant, marker) {
  let reviews = [];
  try {
    const res  = await fetch(`${API_BASE}/api/restaurants/${restaurant.id}/reviews`);
    const json = await res.json();
    if (json.success) reviews = json.data;
  } catch (e) { /* 忽略 */ }

  const stars = ratingToStars(restaurant.avgRating);
  const statusTag = restaurant.isOpen !== false
    ? '<span style="color:#52c41a;font-size:12px;">● 营业中</span>'
    : '<span style="color:#ff4d4f;font-size:12px;">● 休息中</span>';

  const imgHtml = restaurant.imagePath
    ? `<div style="margin:8px 0;"><img src="${escHtml(restaurant.imagePath)}" style="max-width:200px;max-height:120px;border-radius:8px;"></div>`
    : '';

  const detailHtml = `
    ${restaurant.avgCost ? '<div class="iw-detail-row"><span class="iw-detail-label">💰 人均：</span>' + restaurant.avgCost + '元</div>' : ''}
    ${restaurant.bestTime ? '<div class="iw-detail-row"><span class="iw-detail-label">⏰ 最佳时间：</span>' + escHtml(restaurant.bestTime) + '</div>' : ''}
  `;

  const reviewHtml = reviews.length === 0
    ? '<p style="color:#bbb;font-size:12px;">还没有评价，来做第一个推荐的人吧 👇</p>'
    : '<ul class="iw-review-list">' +
      reviews.map(rv => `
        <li class="iw-review-item">
          <div><span class="iw-reviewer">${escHtml(rv.reviewerName || '匿名')}</span>
          <span class="iw-review-rating">${ratingToStars(rv.rating)}</span>
          <span class="iw-review-tag" style="${getReviewTagStyle(rv.rating)}">${getStarLabel(rv.rating)}</span>
          <span class="iw-review-time">${formatTime(rv.createdAt)}</span></div>
          ${rv.recommendReason ? '<div style="color:#aaa;font-size:11px;margin:2px 0;">💡 ' + escHtml(rv.recommendReason) + '</div>' : ''}
          ${rv.signatureDishes ? '<div style="color:#888;font-size:11px;">🍽️ ' + escHtml(rv.signatureDishes) + '</div>' : ''}
          ${rv.images && rv.images.length > 0 ? '<div style="display:flex;flex-wrap:wrap;gap:4px;margin:4px 0;">' + rv.images.map(img => `<img src="${escHtml(img)}" style="width:52px;height:52px;object-fit:cover;border-radius:6px;cursor:pointer;border:1px solid rgba(200,190,175,0.15);" onclick="window.open(this.src,'_blank')">`).join('') + '</div>' : ''}
          ${rv.comment ? '<div class="iw-review-comment" style="margin-top:2px;">' + escHtml(rv.comment) + '</div>' : ''}
        </li>`).join('') + '</ul>';

  let similarHtml = '';
  if (restaurant.category) {
    const similar = restaurants
      .filter(r => r.category === restaurant.category && r.id !== restaurant.id)
      .slice(0, 3);
    if (similar.length > 0) {
      similarHtml = '<div style="margin-top:8px;"><div style="font-size:11px;color:#999;margin-bottom:4px;">同类推荐：</div>' +
        similar.map(s => `<div style="font-size:12px;padding:3px 0;cursor:pointer;" onclick="focusRestaurant(${s.id})">${escHtml(s.name)} <span style="color:#b0a48c;">${parseFloat(s.avgRating) > 0 ? s.avgRating + '分' : ''}</span></div>`).join('') +
        '</div>';
    }
  }

  const content = `
    <div class="iw-mobile-wrap">
      ${imgHtml}
      <div class="iw-restaurant-name">${escHtml(restaurant.name)}</div>
      <span class="iw-category">${escHtml(restaurant.category || '未分类')}</span>
      <span style="margin-left:8px;">${statusTag}</span>
      <div class="iw-rating">${stars} ${restaurant.avgRating > 0 ? restaurant.avgRating : '暂无评分'}</div>
      ${restaurant.address ? '<div class="iw-address">📍 ' + escHtml(restaurant.address) + '</div>' : ''}
      ${detailHtml}
      ${similarHtml}
      <button class="iw-add-review-btn" onclick="showReviewForm(${restaurant.id})">✍️ 写评价</button>
      <div id="review-form-${restaurant.id}" class="iw-review-form" style="display:none;">
        <input  id="rv-name-${restaurant.id}"  placeholder="你的昵称（选填）" style="margin-bottom:4px;">
        <div class="star-rating" id="rv-star-${restaurant.id}" data-rv="${restaurant.id}">
          <span class="star" data-value="1">★</span>
          <span class="star" data-value="2">★</span>
          <span class="star" data-value="3">★</span>
          <span class="star" data-value="4">★</span>
          <span class="star" data-value="5">★</span>
        </div>
        <div class="star-label" id="rv-star-label-${restaurant.id}">点击星星评分</div>
        <input id="rv-reason-${restaurant.id}" placeholder="推荐理由（选填）" style="margin:4px 0;">
        <input id="rv-dishes-${restaurant.id}" placeholder="招牌菜，如：毛肚、鸭肠（选填）" style="margin:4px 0;">
        <input id="rv-cost-${restaurant.id}" placeholder="人均消费（选填）" type="number" style="margin:4px 0;width:50%;">
        <div class="rv-image-upload" id="rv-upload-${restaurant.id}" style="margin:6px 0;padding:8px;border:1px dashed rgba(200,190,175,0.3);border-radius:8px;cursor:pointer;text-align:center;color:#999;font-size:11px;" onclick="document.getElementById('rv-file-${restaurant.id}').click()">
          📷 点击上传图片（可选）
        </div>
        <input type="file" id="rv-file-${restaurant.id}" accept="image/*" style="display:none;" onchange="uploadReviewImage(${restaurant.id})">
        <div class="rv-image-preview" id="rv-preview-${restaurant.id}" style="display:flex;flex-wrap:wrap;gap:4px;margin:4px 0;"></div>
        <textarea id="rv-comment-${restaurant.id}" placeholder="说说你的感受（选填）"></textarea>
        <div>
          <button class="btn-sm btn-sm-primary" onclick="submitReview(${restaurant.id})">提交</button>
          <button class="btn-sm btn-sm-secondary" onclick="hideReviewForm(${restaurant.id})">取消</button>
        </div>
      </div>
      ${reviewHtml}
    </div>`;

  if (currentInfoWindow) currentInfoWindow.close();
  currentInfoWindow = new AMap.InfoWindow({
    content,
    offset: new AMap.Pixel(0, -40),
    closeWhenClickMap: true
  });
  currentInfoWindow.open(map, marker.getPosition());
}

// ==================== 侧边栏列表 ====================
function renderSidebarList() {
  const listEl = document.getElementById('restaurant-list');

  let filtered = restaurants;
  if (activeCategory) filtered = filtered.filter(r => r.category === activeCategory);
  if (activeRatingFilter > 0) filtered = filtered.filter(r => getRatingLevel(r.avgRating) === activeRatingFilter);
  if (topSearchValue) {
    filtered = filtered.filter(r =>
      r.name.toLowerCase().includes(topSearchValue) ||
      (r.address && r.address.toLowerCase().includes(topSearchValue)) ||
      (r.searchKeywords && r.searchKeywords.includes(topSearchValue))
    );
  }

  if (filtered.length === 0) {
    listEl.innerHTML = '<div class="empty-state"><span class="empty-state-icon">🔍</span><div class="empty-state-title">没找到这家店</div><div class="empty-state-desc">换个关键词试试？<br>比如搜索"火锅"、"小面"或餐厅名</div><button class="btn btn-primary" onclick="showRecommendModal()">🏷️ 推荐一家</button></div>';
    return;
  }

  listEl.innerHTML = filtered.map((r, idx) => {
    const { emoji } = getCategoryStyle(r.category);
    const rating = parseFloat(r.avgRating) || 0;
    const mood = rating >= 4.5 ? '🤩' : rating >= 3.5 ? '😋' : rating >= 2.5 ? '🙂' : rating > 0 ? '😫' : '💭';
    const ratingLabel = rating >= 4.5 ? '夯' : rating >= 3.5 ? '顶级' : rating >= 2.5 ? '人上人' : rating > 0 ? 'NPC' : '';
    return `<div class="restaurant-card" data-id="${r.id}" style="animation-delay:${idx * 0.05}s">
      ${r.imagePath ? `<img src="${escHtml(r.imagePath)}" class="card-image" alt="">` : ''}
      <div class="card-top">
        <span class="card-emoji">${emoji}</span>
        <span class="card-name">${escHtml(r.name)}</span>
        <span class="card-mood">${mood}</span>
      </div>
      <div class="card-meta">${r.reviewCount || 0} 条评价 ${rating > 0 ? `· <span class="card-rating-val">${rating}分 ${ratingLabel}</span>` : ''}${r.avgCost > 0 ? ` · 人均${r.avgCost}元` : ''}</div>
      <span class="card-category">${escHtml(r.category || '未分类')}</span>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.restaurant-card').forEach(card => {
    card.addEventListener('click', () => {
      const id = Number(card.dataset.id);
      const r = restaurants.find(x => x.id === id);
      if (!r) return;
      // 选中态
      listEl.querySelectorAll('.restaurant-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      map.setCenter([r.longitude, r.latitude]);
      map.setZoom(15);
      const marker = markers.find(m => m.restaurantId === id);
      if (marker) openInfoWindow(r, marker);
    });
  });
}

// ==================== 分类：从后端加载 ====================
function loadCategories(callback) {
  fetch(`${API_BASE}/api/categories`)
    .then(res => res.json())
    .then(json => {
      if (json.success) {
        categories = json.data;
        renderCategoryBar();
      }
      if (callback) callback();
    })
    .catch(() => {
      categories = [
        {id:1,name:'火锅'},{id:2,name:'小面'},{id:3,name:'烧烤'},
        {id:4,name:'江湖菜'},{id:5,name:'串串'},{id:6,name:'其他'}
      ];
      renderCategoryBar();
      if (callback) callback();
    });
}

function renderCategoryBar() {
  const bar = document.getElementById('category-bar');
  let html = `<button class="cat-btn active" data-cat="">全部 <span class="cat-count" id="count-all">0</span></button>`;
  categories.forEach(cat => {
    html += `<button class="cat-btn" data-cat="${escHtml(cat.name)}">
      ${getCatEmoji(cat.name)} ${escHtml(cat.name)} <span class="cat-count" id="count-${escHtml(cat.name)}">0</span>
    </button>`;
  });
  bar.innerHTML = html;

  bar.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.cat;
      activeCategory = activeCategory === cat ? '' : cat;
      syncCategoryButtons();
      renderMarkers();
      renderSidebarList();
    });
  });
}

function getCatEmoji(name) {
  const map = {'火锅':'🌶️','小面':'🍜','烧烤':'🍢','江湖菜':'🥘','串串':'🍡','咖啡店':'☕','景点':'📍','夜宵':'🌙'};
  return map[name] || '🍽️';
}

function syncCategoryButtons() {
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.cat === activeCategory);
  });
}

// ==================== 成就系统 ====================
function showAchievementModal() {
  document.getElementById('achievement-modal').style.display = 'flex';
  loadAchievements();
  // 延迟一点播彩带，等列表渲染完
  setTimeout(() => showConfetti(), 400);
}

function hideAchievementModal() {
  document.getElementById('achievement-modal').style.display = 'none';
}

async function loadAchievements() {
  try {
    const res1 = await fetch(`${API_BASE}/api/achievements?deviceId=${encodeURIComponent(getDeviceId())}`);
    const json1 = await res1.json();
    if (!json1.success) throw new Error(json1.error);

    const res2 = await fetch(`${API_BASE}/api/user/achievements?deviceId=${encodeURIComponent(getDeviceId())}`);
    const json2 = await res2.json();
    if (!json2.success) throw new Error(json2.error);

    renderAchievements(json1.data, json2.data);
  } catch (err) {
    console.error('加载成就失败：', err);
    document.getElementById('achievement-list').innerHTML =
      '<p class="empty-hint">加载失败，请稍后重试</p>';
  }
}

function renderAchievements(allAchievements, userAchievements) {
  const listEl = document.getElementById('achievement-list');

  if (allAchievements.length === 0) {
    listEl.innerHTML = '<p class="empty-hint">暂无成就定义</p>';
    return;
  }

  listEl.innerHTML = allAchievements.map((achievement, idx) => {
    const isUnlocked = achievement.isUnlocked;
    const conditionText = achievement.conditionText || '';
    const progress = achievement.currentProgress || 0;
    const threshold = achievement.threshold || 1;
    const percentage = achievement.progressPercentage || 0;
    const progressDisplay = isUnlocked
      ? ''
      : `<div class="achievement-progress-wrap">
           <div class="achievement-progress-bar">
             <div class="achievement-progress-fill" style="width:${percentage}%"></div>
           </div>
           <span class="achievement-progress-text">${progress} / ${threshold}</span>
         </div>`;

    return `<div class="achievement-card ${isUnlocked ? 'unlocked' : 'locked'}" style="animation-delay:${idx * 0.05}s">
      <div class="achievement-icon ${isUnlocked ? '' : 'grayscale'}">${achievement.icon}</div>
      <div class="achievement-info">
        <div class="achievement-name">${isUnlocked ? achievement.name : '???'}</div>
        <div class="achievement-desc">${isUnlocked ? achievement.description : conditionText}</div>
        <div class="achievement-condition">${isUnlocked ? '✅ ' + conditionText : '🔓 ' + conditionText}</div>
        ${progressDisplay}
      </div>
      <div class="achievement-status">
        ${isUnlocked ? '<span class="achievement-badge">✅ 已解锁</span>' : '<span class="achievement-badge locked">🔒 未解锁</span>'}
      </div>
    </div>`;
  }).join('');
}

// ==================== ★ 效果6：今天吃什么 · 老虎机效果 ====================
function showRandomRestaurant() {
  if (!restaurants || restaurants.length === 0) {
    showErrorToast('还没有餐厅数据，先添加一些餐厅吧！');
    return;
  }

  const btn = document.getElementById('btn-random');
  btn.style.animation = 'none';
  btn.style.transform = 'scale(0.95)';

  let candidates = restaurants.filter(r => parseFloat(r.avgRating) > 0);
  if (candidates.length === 0) candidates = restaurants;

  const weights = candidates.map(r => Math.max(1, parseFloat(r.avgRating) || 1));
  const totalWeight = weights.reduce((s, w) => s + w, 0);
  let rand = Math.random() * totalWeight;
  let randomRestaurant = candidates[0];
  for (let i = 0; i < candidates.length; i++) {
    rand -= weights[i];
    if (rand <= 0) { randomRestaurant = candidates[i]; break; }
  }

  setTimeout(() => {
    btn.style.transform = '';
    btn.style.animation = '';
    showSlotMachine(randomRestaurant);
  }, 300);
}

function showSlotMachine(targetRestaurant) {
  const overlay = document.createElement('div');
  overlay.className = 'slot-machine-overlay';
  overlay.innerHTML = `
    <div class="slot-machine-card">
      <div style="font-size:13px;color:#ff6b6b;font-weight:600;letter-spacing:1px;margin-bottom:12px;">🎰 今天吃什么 🎰</div>
      <div id="slot-emoji" style="font-size:48px;margin:8px 0;transition:opacity 0.05s;">🎲</div>
      <div id="slot-name" style="font-size:18px;font-weight:700;color:#4a453e;margin:4px 0;min-height:28px;transition:opacity 0.05s;"></div>
      <div id="slot-category" style="font-size:12px;color:#8a7e6c;transition:opacity 0.05s;"></div>
      <div id="slot-rating" style="font-size:13px;color:#b0a48c;margin-top:4px;transition:opacity 0.05s;"></div>
    </div>`;
  document.body.appendChild(overlay);

  const emojiEl  = document.getElementById('slot-emoji');
  const nameEl   = document.getElementById('slot-name');
  const catEl    = document.getElementById('slot-category');
  const ratingEl = document.getElementById('slot-rating');

  const shuffled = [...restaurants].sort(() => Math.random() - 0.5);
  let idx = 0;
  const totalTicks = 18 + Math.floor(Math.random() * 8);
  let tick = 0;

  const tickInterval = setInterval(() => {
    const r = shuffled[idx % shuffled.length];
    const { emoji } = getCategoryStyle(r.category);
    emojiEl.textContent = emoji;
    nameEl.textContent = r.name;
    nameEl.style.opacity = 0.4 + Math.random() * 0.6;
    catEl.textContent = getCatEmoji(r.category || '其他') + ' ' + (r.category || '其他');
    const rt = parseFloat(r.avgRating) || 0;
    ratingEl.textContent = rt > 0 ? '★ '.repeat(Math.round(rt)) + rt.toFixed(1) + '分' : '暂无评分';
    idx++;
    tick++;

    if (tick === totalTicks - 3) clearInterval(tickInterval), finalCountdown();
  }, 60);

  function finalCountdown() {
    let remain = 3;
    const finalInterval = setInterval(() => {
      remain--;
      if (remain <= 0) {
        clearInterval(finalInterval);
        const { emoji } = getCategoryStyle(targetRestaurant.category);
        emojiEl.textContent = emoji;
        emojiEl.style.animation = 'unlockPop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)';
        nameEl.textContent = targetRestaurant.name;
        nameEl.style.opacity = 1;
        nameEl.style.color = '#c84a3f';
        catEl.textContent = getCatEmoji(targetRestaurant.category || '其他') + ' ' + (targetRestaurant.category || '其他');
        const rt = parseFloat(targetRestaurant.avgRating) || 0;
        ratingEl.textContent = rt > 0 ? '★ '.repeat(Math.round(rt)) + rt.toFixed(1) + '分' : '暂无评分';
        ratingEl.style.opacity = 1;

        setTimeout(() => {
          overlay.style.opacity = '0';
          overlay.style.transition = 'opacity 0.3s';
          setTimeout(() => {
            if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
            showRandomResult(targetRestaurant);
          }, 350);
        }, 1500);
        return;
      }
      const r = shuffled[idx % shuffled.length];
      const { emoji: emj } = getCategoryStyle(r.category);
      emojiEl.textContent = emj;
      nameEl.textContent = r.name;
      idx++;
    }, 200 + (3 - remain) * 100);
  }
}

function showRandomResult(restaurant) {
  map.setCenter([restaurant.longitude, restaurant.latitude]);
  map.setZoom(16);

  const marker = markers.find(m => m.restaurantId === restaurant.id);
  if (marker) {
    const bubble = marker.getContent().querySelector('.marker-bubble');
    if (bubble) {
      bubble.style.animation = 'markerPulse 0.5s ease-in-out 3';
      setTimeout(() => { bubble.style.animation = ''; }, 1500);
    }
    setTimeout(() => { openInfoWindow(restaurant, marker); }, 500);
  }

  showRandomNotification(restaurant);
}

function showRandomNotification(restaurant) {
  const notification = document.createElement('div');
  notification.className = 'random-notification';
  notification.innerHTML = `
    <div class="random-notification-content">
      <div class="random-emoji">🎲</div>
      <div class="random-text">
        <div class="random-title">今天吃这个！</div>
        <div class="random-name">${escHtml(restaurant.name)}</div>
        <div class="random-category">${getCatEmoji(restaurant.category || '其他')} ${escHtml(restaurant.category || '其他')}</div>
      </div>
      <button class="random-reroll-btn" title="换一个">🔄</button>
    </div>`;

  // 换一个按钮
  const rerollBtn = notification.querySelector('.random-reroll-btn');
  if (rerollBtn) {
    rerollBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      // 清除当前通知
      notification.classList.remove('show');
      setTimeout(() => {
        if (notification.parentNode) notification.parentNode.removeChild(notification);
      }, 300);
      // 重新随机
      showRandomRestaurant();
    });
  }

  document.body.appendChild(notification);

  setTimeout(() => { notification.classList.add('show'); }, 10);

  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      if (notification.parentNode) { notification.parentNode.removeChild(notification); }
    }, 300);
  }, 3000);
}

// ==================== ★ 效果7：成就解锁彩带粒子 ====================
function showConfetti() {
  const old = document.querySelector('.confetti-overlay');
  if (old) old.parentNode.removeChild(old);

  const overlay = document.createElement('div');
  overlay.className = 'confetti-overlay';
  document.body.appendChild(overlay);

  const colors = ['#c84a3f','#e67e22','#27ae60','#3498db','#9b59b6','#f39c12','#ff6b6b','#1abc9c'];

  for (let i = 0; i < 60; i++) {
    const particle = document.createElement('div');
    particle.className = 'confetti-particle';
    const color = colors[Math.floor(Math.random() * colors.length)];
    const left = Math.random() * 100;
    const delay = Math.random() * 0.8;
    const duration = 1.5 + Math.random() * 1.5;
    const size = 6 + Math.random() * 8;
    const height = 12 + Math.random() * 10;
    particle.style.cssText = `
      background: ${color};
      left: ${left}%;
      top: -20px;
      width: ${size}px;
      height: ${height}px;
      border-radius: ${Math.random() > 0.5 ? '50%' : '2px'};
      animation: confettiFall ${duration}s linear ${delay}s forwards;
    `;
    overlay.appendChild(particle);
  }

  setTimeout(() => {
    overlay.style.opacity = '0';
    overlay.style.transition = 'opacity 0.5s';
    setTimeout(() => {
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
    }, 600);
  }, 2000);
}

// ==================== ★ 效果8：搜索框趣味占位文案轮换 ====================
const PLACEHOLDER_TEXTS = [
  '搜索餐厅名称...',
  '想吃什么？火锅还是小面？',
  '输入店名，比如"珮姐"...',
  '找不到？试试"毛肚"...',
  '深夜了，来碗小面？',
  '搜索你最想念的那口味道...'
];
let placeholderIdx = 0;
let placeholderInterval = null;

function initRotatingPlaceholder() {
  const input = document.getElementById('top-search');
  if (!input) return;

  input.placeholder = PLACEHOLDER_TEXTS[0];

  input.addEventListener('focus', () => {
    if (placeholderInterval) clearInterval(placeholderInterval);
    placeholderInterval = null;
    input.placeholder = '搜索餐厅名称或描述...';
  });

  input.addEventListener('blur', () => {
    if (!placeholderInterval && !input.value) {
      startPlaceholderRotation(input);
    }
  });

  if (!input.value) startPlaceholderRotation(input);
}

function startPlaceholderRotation(input) {
  placeholderInterval = setInterval(() => {
    placeholderIdx = (placeholderIdx + 1) % PLACEHOLDER_TEXTS.length;
    input.style.opacity = '0.3';
    setTimeout(() => {
      input.placeholder = PLACEHOLDER_TEXTS[placeholderIdx];
      input.style.opacity = '1';
    }, 200);
  }, 2500);
}

// ==================== 工具函数 ====================
function ratingToStars(rating) {
  const n = Math.round(rating || 0);
  let html = '<span class="star-display">';
  for (let i = 1; i <= 5; i++) {
    html += `<span class="star-display-item ${i <= n ? 'filled' : ''}">★</span>`;
  }
  html += '</span>';
  return html;
}

function getStarLabel(rating) {
  return STAR_LABELS[rating] || '';
}

function initStarRating(containerId, labelId, inputId) {
  const container = document.getElementById(containerId);
  const labelEl = document.getElementById(labelId);
  const inputEl = document.getElementById(inputId);
  if (!container) return;

  let currentValue = 0;

  function updateStars(value, isHover) {
    container.querySelectorAll('.star').forEach((star, idx) => {
      const starValue = idx + 1;
      star.classList.toggle('filled', starValue <= value);
      star.classList.toggle('hover', isHover && starValue <= value);
    });
    if (labelEl) {
      labelEl.textContent = value > 0 ? STAR_LABELS[value] : '点击星星评分';
      labelEl.classList.toggle('selected', value > 0);
    }
  }

  container.querySelectorAll('.star').forEach((star, idx) => {
    star.addEventListener('mouseenter', () => updateStars(idx + 1, true));
    star.addEventListener('mouseleave', () => updateStars(currentValue, false));
    star.addEventListener('click', () => {
      currentValue = idx + 1;
      updateStars(currentValue, false);
      if (inputEl) inputEl.value = currentValue;
    });
  });

  container.addEventListener('mouseleave', () => updateStars(currentValue, false));
}

function resetStarRating(containerId, labelId, inputId) {
  const container = document.getElementById(containerId);
  const labelEl = document.getElementById(labelId);
  const inputEl = document.getElementById(inputId);
  if (container) {
    container.querySelectorAll('.star').forEach(s => s.classList.remove('filled', 'hover'));
  }
  if (labelEl) {
    labelEl.textContent = '点击星星评分';
    labelEl.classList.remove('selected');
  }
  if (inputEl) inputEl.value = '';
}

function initStarRatingInline(containerId, labelId, inputId) {
  const container = document.getElementById(containerId);
  const labelEl = document.getElementById(labelId);
  const inputEl = document.getElementById(inputId);
  if (!container || container._starInited) return;
  container._starInited = true;

  let currentValue = 0;
  function updateStars(value, isHover) {
    container.querySelectorAll('.star').forEach((star, idx) => {
      const starValue = idx + 1;
      star.classList.toggle('filled', starValue <= value);
      star.classList.toggle('hover', isHover && starValue <= value);
    });
    if (labelEl) {
      labelEl.textContent = value > 0 ? STAR_LABELS[value] : '点击星星评分';
      labelEl.classList.toggle('selected', value > 0);
    }
  }

  container.querySelectorAll('.star').forEach((star, idx) => {
    star.addEventListener('mouseenter', () => updateStars(idx + 1, true));
    star.addEventListener('mouseleave', () => updateStars(currentValue, false));
    star.addEventListener('click', () => {
      currentValue = idx + 1;
      updateStars(currentValue, false);
      if (inputEl) inputEl.value = currentValue;
    });
  });
  container.addEventListener('mouseleave', () => updateStars(currentValue, false));
}

function escHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return `${d.getMonth()+1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
}

window.focusRestaurant = function(id) {
  const r = restaurants.find(x => x.id === id);
  if (!r) return;
  map.setCenter([r.longitude, r.latitude]);
  map.setZoom(15);
  const marker = markers.find(m => m.restaurantId === id);
  if (marker) openInfoWindow(r, marker);
};

// ==================== Toast 提示 ====================
function showAchievementUnlockToast(achievements) {
  achievements.forEach((a, idx) => {
    setTimeout(() => {
      const toast = document.createElement('div');
      toast.className = 'toast-notification achievement-toast';
      toast.innerHTML = `<span class="toast-icon">${a.icon || '🏆'}</span><span class="toast-message">成就解锁：${escHtml(a.name || '???')} - ${escHtml(a.description || '')}</span>`;
      document.body.appendChild(toast);
      setTimeout(() => toast.classList.add('show'), 10);
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 400);
      }, 4000);
    }, idx * 1200);
  });
}

function showSuccessToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast-notification';
  toast.innerHTML = `<span class="toast-icon">✓</span><span class="toast-message">${escHtml(message)}</span>`;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 400);
  }, 3000);
}

function showErrorToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast-notification error';
  toast.innerHTML = `<span class="toast-icon">!</span><span class="toast-message">${escHtml(message)}</span>`;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 400);
  }, 3000);
}

// ==================== 排行榜系统 ====================
function showRankingModal() {
  document.getElementById('ranking-modal').style.display = 'flex';
  activeRankingTab = 'rating';
  updateRankingTabs();
  loadRanking('rating');
}

function hideRankingModal() {
  document.getElementById('ranking-modal').style.display = 'none';
}

let activeRankingTab = 'rating';

function updateRankingTabs() {
  document.querySelectorAll('.ranking-tab').forEach(tab => {
    tab.classList.toggle('active', tab.dataset.tab === activeRankingTab);
  });
}

async function loadRanking(type) {
  try {
    const listEl = document.getElementById('ranking-list');
    listEl.innerHTML = '<p class="empty-hint">加载中...</p>';

    const res = await fetch(`${API_BASE}/api/restaurants`);
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    let restaurants = json.data;

    if (type === 'rating') {
      restaurants = restaurants.filter(r => parseFloat(r.avgRating) > 0);
      restaurants.sort((a, b) => parseFloat(b.avgRating) - parseFloat(a.avgRating));
    } else if (type === 'reviews') {
      restaurants.sort((a, b) => b.reviewCount - a.reviewCount);
    } else if (type === 'recent') {
      restaurants.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    restaurants = restaurants.slice(0, 10);
    renderRanking(restaurants, type);
  } catch (err) {
    console.error('加载排行榜失败：', err);
    document.getElementById('ranking-list').innerHTML =
      '<p class="empty-hint">加载失败，请稍后重试</p>';
  }
}

function renderRanking(restaurants, type) {
  const listEl = document.getElementById('ranking-list');

  if (restaurants.length === 0) {
    listEl.innerHTML = '<p class="empty-hint">暂无数据</p>';
    return;
  }

  const medals = ['🥇', '🥈', '🥉'];

  listEl.innerHTML = restaurants.map((r, idx) => {
    const medal = idx < 3 ? medals[idx] : `${idx + 1}`;
    const { emoji } = getCategoryStyle(r.category);
    const rating = parseFloat(r.avgRating) || 0;

    let scoreText = '';
    if (type === 'rating') {
      scoreText = `评分：${rating > 0 ? rating.toFixed(1) : '暂无'}`;
    } else if (type === 'reviews') {
      scoreText = `评价：${r.reviewCount || 0}条`;
    } else if (type === 'recent') {
      scoreText = `添加：${formatTime(r.createdAt)}`;
    }

    return `<div class="ranking-card" data-id="${r.id}" style="animation-delay:${idx * 0.05}s">
      <div class="ranking-rank">${medal}</div>
      <div class="ranking-emoji">${emoji}</div>
      <div class="ranking-info">
        <div class="ranking-name">${escHtml(r.name)}</div>
        <div class="ranking-score">${scoreText}</div>
      </div>
      <div class="ranking-category">
        <span class="card-category">${escHtml(r.category || '未分类')}</span>
      </div>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.ranking-card').forEach(card => {
    card.addEventListener('click', () => {
      const id = Number(card.dataset.id);
      const r = restaurants.find(x => x.id === id);
      if (!r) return;
      map.setCenter([r.longitude, r.latitude]);
      map.setZoom(15);
      const marker = markers.find(m => m.restaurantId === id);
      if (marker) openInfoWindow(r, marker);
      hideRankingModal();
    });
  });

  document.querySelectorAll('.ranking-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      activeRankingTab = tab.dataset.tab;
      updateRankingTabs();
      loadRanking(activeRankingTab);
    });
  });
}

// ==================== ★ 效果10：点赞大拇指向爆开 + 粒子爆散 + 庆祝Toast ====================
function showChiliOilRipple(lat, lng) {
  const mapContainer = document.getElementById('map-container');
  if (!mapContainer) return;

  const pixel = map.lngLatToContainer(new AMap.LngLat(lng, lat));
  const cx = pixel.x, cy = pixel.y;

  // ① 容器
  const ripple = document.createElement('div');
  ripple.className = 'chili-oil-ripple';
  ripple.style.left = cx + 'px';
  ripple.style.top  = cy + 'px';

  // ② Emoji 大拇指图标（原生表情包级精致度）
  const thumb = document.createElement('div');
  thumb.className = 'thumb-emoji';
  thumb.textContent = '👍';
  ripple.appendChild(thumb);

  // ③ +1 浮动文字
  const plus = document.createElement('div');
  plus.className = 'chili-plus-one';
  plus.textContent = '+1';
  plus.style.left = cx + 'px';
  plus.style.top  = (cy - 40) + 'px';
  plus.style.transform = 'translateX(-50%)';
  mapContainer.appendChild(plus);

  mapContainer.appendChild(ripple);

  // ④ 450ms 后爆散辣椒粒子
  setTimeout(() => createChiliParticles(cx, cy, mapContainer), 450);

  // ⑤ 900ms 后滑入庆祝 Toast
  setTimeout(() => showChiliToast(), 900);

  // ⑥ 3.8s 后全部清理
  setTimeout(() => {
    if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
    if (plus.parentNode) plus.parentNode.removeChild(plus);
    removeChiliParticles(mapContainer);
    removeChiliToast();
  }, 3800);
}

// 创建 8 个辣椒粒子，随机方向飞散
function createChiliParticles(cx, cy, container) {
  const emojis = ['🌶️', '✨', '🔥', '💥', '🌶️', '✨', '🔥', '💥'];
  emojis.forEach((emoji, i) => {
    const p = document.createElement('div');
    p.className = 'chili-particle';
    p.textContent = emoji;
    const angle = (i / 8) * 360 + (Math.random() * 28 - 14); // 随机偏移
    const dist  = 90 + Math.random() * 130;                  // 飞行距离
    const tx    = Math.cos(angle * Math.PI / 180) * dist;
    const ty    = Math.sin(angle * Math.PI / 180) * dist;
    p.style.left     = cx + 'px';
    p.style.top      = cy + 'px';
    p.style.setProperty('--tx', tx + 'px');
    p.style.setProperty('--ty', ty + 'px');
    container.appendChild(p);
  });
}

// 移除所有辣椒粒子
function removeChiliParticles(container) {
  container.querySelectorAll('.chili-particle').forEach(p => {
    if (p.parentNode) p.parentNode.removeChild(p);
  });
}

// 显示庆祝 Toast
function showChiliToast() {
  removeChiliToast(); // 防止重复
  const toast = document.createElement('div');
  toast.id    = 'chili-toast';
  toast.className = 'chili-toast';
  toast.innerHTML = '🎉 儿豁！又多一个店可以尝了 🫶！谢！';
  document.body.appendChild(toast);
  // 强制回流后加 .show 触发过渡动画
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('show'));
  });
}

// 移除庆祝 Toast
function removeChiliToast() {
  const old = document.getElementById('chili-toast');
  if (old && old.parentNode) old.parentNode.removeChild(old);
}

// ==================== iOS 键盘弹跳修复 ====================
(function fixIOSKeyboardBounce() {
  // 仅对 iOS 设备生效
  if (!/iPad|iPhone|iPod/.test(navigator.userAgent)) return;

  const handleFocus = (e) => {
    const target = e.target;
    if (!target.matches('input, textarea, select')) return;
    requestAnimationFrame(() => {
      target.scrollIntoView({ block: 'center', behavior: 'smooth' });
    });
  };

  const handleBlur = () => {
    // 键盘收起后滚动回顶部
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 200);
  };

  document.addEventListener('focusin', handleFocus);
  document.addEventListener('focusout', handleBlur);

  // 防止 iOS 下拉刷新导致地图偏移
  document.body.addEventListener('touchmove', (e) => {
    if (e.target.closest('.modal, .modal-overlay, .restaurant-list, .achievement-list, .ranking-list')) return;
    if (window.scrollY === 0) e.preventDefault();
  }, { passive: false });
})();

// 恢复图例面板偏好
(function restoreRatingLegend() {
  try {
    const saved = localStorage.getItem('ratingLegendExpanded');
    if (saved === 'true') {
      const panel = document.getElementById('rating-legend-panel');
      if (panel) panel.classList.add('expanded');
    }
  } catch(e) {}
})();

// ==================== 评分图例面板 ====================
function toggleRatingLegend() {
  const panel = document.getElementById('rating-legend-panel');
  if (!panel) return;
  panel.classList.toggle('expanded');
  try { localStorage.setItem('ratingLegendExpanded', panel.classList.contains('expanded')); } catch(e) {}
}

// ==================== 移动端侧边栏展开/收起 ====================
(function initMobileSidebar() {
  function setup() {
    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    if (!isMobile) return;

    const sidebar = document.getElementById('sidebar');
    const list = document.getElementById('restaurant-list');
    if (!sidebar || sidebar.querySelector('.sidebar-toggle-bar')) return;

    // 动态插入展开/收起手柄
    const toggleBar = document.createElement('div');
    toggleBar.className = 'sidebar-toggle-bar';
    toggleBar.setAttribute('role', 'button');
    toggleBar.setAttribute('aria-label', '展开或收起餐厅列表');
    toggleBar.innerHTML = '<span class="toggle-icon">▼</span><span>查看附近美食</span>';

    if (list && list.parentNode === sidebar) {
      sidebar.insertBefore(toggleBar, list);
    } else {
      sidebar.appendChild(toggleBar);
    }

    // 点击切换展开/收起
    toggleBar.addEventListener('click', () => {
      const expanded = sidebar.classList.toggle('sidebar-expanded');
      const textSpan = toggleBar.querySelector('span:last-child');
      if (textSpan) {
        textSpan.textContent = expanded ? '收起列表 ▲' : '查看附近美食';
      }
    });
  }

  // DOM 就绪后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setup);
  } else {
    setup();
  }

  // 窗口大小变化时重新检测
  window.addEventListener('resize', () => {
    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    const sidebar = document.getElementById('sidebar');
    const toggleBar = sidebar && sidebar.querySelector('.sidebar-toggle-bar');
    if (!isMobile && toggleBar) {
      toggleBar.remove();
      sidebar.classList.remove('sidebar-expanded');
    } else if (isMobile && !toggleBar) {
      setup();
    }
  });
})();

// ==================== 评分等级过滤 ====================
(function initRatingFilter() {
  function setup() {
    const items = document.querySelectorAll('.rating-legend-item');
    if (!items.length) return;

    items.forEach(item => {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        const rating = parseInt(this.dataset.rating);
        if (!rating) return;

        // 切换过滤：点击同一个等级取消过滤
        if (activeRatingFilter === rating) {
          activeRatingFilter = 0;
          items.forEach(el => el.classList.remove('rating-filter-active'));
        } else {
          activeRatingFilter = rating;
          items.forEach(el => el.classList.remove('rating-filter-active'));
          this.classList.add('rating-filter-active');
        }

        renderMarkers();
        renderSidebarList();
      });
    });
  }

  // 等 DOM 和评分面板都加载完后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(setup, 300));
  } else {
    setTimeout(setup, 300);
  }
})();

// ==================== 弹窗键盘遮挡修复 ====================
(function fixModalKeyboard() {
  document.addEventListener('focusin', (e) => {
    const modal = e.target.closest('.modal');
    if (!modal) return;
    setTimeout(() => {
      const submitBtn = modal.querySelector('.modal-buttons .btn');
      if (submitBtn) submitBtn.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }, 300);
  });
})();
